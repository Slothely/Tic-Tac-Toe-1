# -*- coding: utf-8 -*-
"""
Created on Thu Jul 22 13:16:38 2021

@author: Drew
"""


import pygame
pygame.init()
clock = pygame.time.Clock()
import csv
from csv import writer
import random

turn1list = []

turn2list = []

turn3list = []

turn4list = []

winlist = []

with open('CSVs_For_TicTacToe\Turn1.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for row in csv_reader:
        for item in row:
            turn1list.append(int(item))

with open('CSVs_For_TicTacToe\Turn2.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for row in csv_reader:
        for item in row:
            turn2list.append(int(item))
            
with open('CSVs_For_TicTacToe\Turn3.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for row in csv_reader:
        for item in row:
            turn3list.append(int(item))

with open('CSVs_For_TicTacToe\Turn4.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for row in csv_reader:
        for item in row:
            turn4list.append(int(item))
            
with open('CSVs_For_TicTacToe\Wins.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for row in csv_reader:
        for item in row:
            winlist.append(item)
    

# =============================================================================
#print(turn1list)
# print(turn2list)
# print(turn3list)
# print(turn4list)
# =============================================================================

print(len(winlist))

            


moves=[]

x = 0
y = 0
width = 120
height = 120
white = 214,212,182
black = 74,71,57
pawnScaleFactor = 0.8
red = 244, 0, 0

sd = [0,0,0,0,0,0,0,0,0]

window = pygame.display.set_mode((width*3,height*3))

s1 = pygame.draw.rect(window, (white), (x,y,width,height))
s3 = pygame.draw.rect(window, (white), ((x+width*2),y,width,height))
s5 = pygame.draw.rect(window, (white), ((x+width),(y+height),width,height))
s7 = pygame.draw.rect(window, (white), ((x),(y+height*2),width,height))
s9 = pygame.draw.rect(window, (white), ((x+width*2),(y+height*2),width,height))

s2 = pygame.draw.rect(window, (black), ((x+width),y,width,height))
s4 = pygame.draw.rect(window, (black), ((x),(y+height),width,height))
s6 = pygame.draw.rect(window, (black), ((x+width*2),(y+height),width,height))
s8 = pygame.draw.rect(window, (black), ((x+width),(y+height*2),width,height))



pygame.display.set_caption("TicTacToe")

ximage = pygame.image.load("x.png")
oimage = pygame.image.load("o.png")

def text_objects(text, font):
    textSurface = font.render(text, True, red)    
    return textSurface, textSurface.get_rect()

def message_display(text):
    wtext = pygame.font.Font('freesansbold.ttf', 40)
    TextSurf, TextRect = text_objects(text, wtext)
    TextRect.center = ((width*1.5), (height*1.5))
    window.blit(TextSurf, TextRect)
    
omove = random.randint(0,9)

def xwin():
    message_display('AI Wins')
    
def owin():
    message_display('Random Wins')
    
def drawmessage():
    message_display('Draw')
xW = False
oW = False
draw = False



turn = 1
#main gameloop
run = True
while run:
    
    
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            exit()
            
        keys = pygame.key.get_pressed()
        
        if keys[pygame.K_q]:
            pygame.quit()
        
        #print(turn)

           
# =============================================================================
#         if event.type == pygame.MOUSEBUTTONUP:
#             
#             mousePos = pygame.mouse.get_pos()
# =============================================================================
        
        
# =============================================================================
#             if s1.collidepoint(mousePos) and sd[0] == 0:
#                 if turn == 1:
#                     pygame.Surface.blit(window, ximage, s1)
#                     sd[0] = 1
#                     turn = 0
#             elif s2.collidepoint(mousePos) and sd[1] == 0:
#                 if turn == 1:
#                     pygame.Surface.blit(window, ximage, s2)
#                     sd[1] = 1
#                     turn = 0
#             elif s3.collidepoint(mousePos) and sd[2] == 0:
#                 if turn == 1:
#                     pygame.Surface.blit(window, ximage, s3)
#                     sd[2] = 1
#                     turn = 0
#             elif s4.collidepoint(mousePos) and sd[3] == 0:
#                 if turn == 1:
#                     pygame.Surface.blit(window, ximage, s4)
#                     sd[3] = 1
#                     turn = 0
#             elif s5.collidepoint(mousePos) and sd[4] == 0:
#                 if turn == 1:
#                     pygame.Surface.blit(window, ximage, s5)
#                     sd[4] = 1
#                     turn = 0
#             elif s6.collidepoint(mousePos) and sd[5] == 0:
#                 if turn == 1:
#                     pygame.Surface.blit(window, ximage, s6)
#                     sd[5] = 1
#                     turn = 0
#             elif s7.collidepoint(mousePos) and sd[6] == 0:
#                 if turn == 1:
#                     pygame.Surface.blit(window, ximage, s7)
#                     sd[6] = 1
#                     turn = 0
#             elif s8.collidepoint(mousePos) and sd[7] == 0:
#                 if turn == 1:
#                     pygame.Surface.blit(window, ximage, s8)
#                     sd[7] = 1
#                     turn = 0
#             elif s9.collidepoint(mousePos) and sd[8] == 0:
#                 if turn == 1:
#                     pygame.Surface.blit(window, ximage, s9)
#                     sd[8] = 1
#                     turn = 0
# =============================================================================
# =============================================================================
#             else:
#                 pass
# =============================================================================


        if turn == 1:
            r1 = turn1list[random.randint(0,len(turn1list)-1)]
            #print(r1)
            if r1 == 0 and sd[0]==0:
                pygame.Surface.blit(window, ximage, s1)
                sd[0] = 1
                moves.append(r1)
                turn += 1 
            elif r1 == 1 and sd[1]==0:
                pygame.Surface.blit(window, ximage, s2)
                sd[1] = 1
                moves.append(r1)
                turn += 1 
            elif r1 == 2 and sd[2]==0:
                pygame.Surface.blit(window, ximage, s3)
                sd[2] = 1
                moves.append(r1)
                turn += 1 
            elif r1 == 3 and sd[3]==0:
                pygame.Surface.blit(window, ximage, s4)
                sd[3] = 1
                moves.append(r1)
                turn += 1 
            elif r1 == 4 and sd[4]==0:
                pygame.Surface.blit(window, ximage, s5)
                sd[4] = 1
                moves.append(r1)
                turn += 1 
            elif r1 == 5 and sd[5]==0:
                pygame.Surface.blit(window, ximage, s6)
                sd[5] = 1
                moves.append(r1)
                turn += 1 
            elif r1 == 6 and sd[6]==0:
                pygame.Surface.blit(window, ximage, s7)
                sd[6] = 1
                moves.append(r1)
                turn += 1 
            elif r1 == 7 and sd[7]==0:
                pygame.Surface.blit(window, ximage, s8)
                sd[7] = 1
                moves.append(r1)
                turn += 1 
            elif r1 == 8 and sd[8]==0:
                pygame.Surface.blit(window, ximage, s9)
                sd[8] = 1
                moves.append(r1)
                turn += 1 
            
                
        if turn == 3:
            r2 = turn2list[random.randint(0,len(turn2list)-1)]
            if r2 == 0 and sd[0]==0:
                pygame.Surface.blit(window, ximage, s1)
                sd[0] = 1
                moves.append(r2)
                turn += 1 
            elif r2 == 1 and sd[1]==0:
                pygame.Surface.blit(window, ximage, s2)
                sd[1] = 1
                moves.append(r2)
                turn += 1 
            elif r2 == 2 and sd[2]==0:
                pygame.Surface.blit(window, ximage, s3)
                sd[2] = 1
                moves.append(r2)
                turn += 1 
            elif r2 == 3 and sd[3]==0:
                pygame.Surface.blit(window, ximage, s4)
                sd[3] = 1
                moves.append(r2)
                turn += 1 
            elif r2 == 4 and sd[4]==0:
                pygame.Surface.blit(window, ximage, s5)
                sd[4] = 1
                moves.append(r2)
                turn += 1 
            elif r2 == 5 and sd[5]==0:
                pygame.Surface.blit(window, ximage, s6)
                sd[5] = 1
                moves.append(r2)
                turn += 1 
            elif r2 == 6 and sd[6]==0:
                pygame.Surface.blit(window, ximage, s7)
                sd[6] = 1
                moves.append(r2)
                turn += 1 
            elif r2 == 7 and sd[7]==0:
                pygame.Surface.blit(window, ximage, s8)
                sd[7] = 1
                moves.append(r2)
                turn += 1 
            elif r2 == 8 and sd[8]==0:
                pygame.Surface.blit(window, ximage, s9)
                sd[8] = 1
                moves.append(r2)
                turn += 1 
                
        if turn == 5:
            r3 = turn3list[random.randint(0,len(turn3list)-1)]
            if r3 == 0 and sd[0]==0:
                pygame.Surface.blit(window, ximage, s1)
                sd[0] = 1
                moves.append(r3)
                turn += 1 
            elif r3 == 1 and sd[1]==0:
                pygame.Surface.blit(window, ximage, s2)
                sd[1] = 1
                moves.append(r3)
                turn += 1 
            elif r3 == 2 and sd[2]==0:
                pygame.Surface.blit(window, ximage, s3)
                sd[2] = 1
                moves.append(r3)
                turn += 1 
            elif r3 == 3 and sd[3]==0:
                pygame.Surface.blit(window, ximage, s4)
                sd[3] = 1
                moves.append(r3)
                turn += 1 
            elif r3 == 4 and sd[4]==0:
                pygame.Surface.blit(window, ximage, s5)
                sd[4] = 1
                moves.append(r3)
                turn += 1 
            elif r3 == 5 and sd[5]==0:
                pygame.Surface.blit(window, ximage, s6)
                sd[5] = 1
                moves.append(r3)
                turn += 1 
            elif r3 == 6 and sd[6]==0:
                pygame.Surface.blit(window, ximage, s7)
                sd[6] = 1
                moves.append(r3)
                turn += 1 
            elif r3 == 7 and sd[7]==0:
                pygame.Surface.blit(window, ximage, s8)
                sd[7] = 1
                moves.append(r3)
                turn += 1 
            elif r3 == 8 and sd[8]==0:
                pygame.Surface.blit(window, ximage, s9)
                sd[8] = 1
                moves.append(r3)
                turn += 1 
                
        if turn == 7:
            r4 = turn4list[random.randint(0,len(turn4list)-1)]
            if r4 == 0 and sd[0]==0:
                pygame.Surface.blit(window, ximage, s1)
                sd[0] = 1
                moves.append(r4)
                turn += 1 
            elif r4 == 1 and sd[1]==0:
                pygame.Surface.blit(window, ximage, s2)
                sd[1] = 1
                moves.append(r4)
                turn += 1 
            elif r4 == 2 and sd[2]==0:
                pygame.Surface.blit(window, ximage, s3)
                sd[2] = 1
                moves.append(r4)
                turn += 1 
            elif r4 == 3 and sd[3]==0:
                pygame.Surface.blit(window, ximage, s4)
                sd[3] = 1
                moves.append(r4)
                turn += 1 
            elif r4 == 4 and sd[4]==0:
                pygame.Surface.blit(window, ximage, s5)
                sd[4] = 1
                moves.append(r4)
                turn += 1 
            elif r4 == 5 and sd[5]==0:
                pygame.Surface.blit(window, ximage, s6)
                sd[5] = 1
                moves.append(r4)
                turn += 1 
            elif r1 == 6 and sd[6]==0:
                pygame.Surface.blit(window, ximage, s7)
                sd[6] = 1
                moves.append(r4)
                turn += 1 
            elif r4 == 7 and sd[7]==0:
                pygame.Surface.blit(window, ximage, s8)
                sd[7] = 1
                moves.append(r4)
                turn += 1 
            elif r4 == 8 and sd[8]==0:
                pygame.Surface.blit(window, ximage, s9)
                sd[8] = 1
                moves.append(r4)
                turn += 1
                
        if turn == 9:
            cpurand = random.randint(0,8)
            if sd[cpurand] == 0:
                if cpurand == 0:
                    pygame.Surface.blit(window, ximage, s1)
                    sd[0] = 1
                    turn += 1 
                elif cpurand == 1:
                    pygame.Surface.blit(window, ximage, s2)
                    sd[1] = 1
                    turn += 1 
                elif cpurand == 2:
                    pygame.Surface.blit(window, ximage, s3)
                    sd[2] = 1
                    turn += 1 
                elif cpurand == 3:
                    pygame.Surface.blit(window, ximage, s4)
                    sd[3] = 1
                    turn += 1 
                elif cpurand == 4:
                    pygame.Surface.blit(window, ximage, s5)
                    sd[4] = 1
                    turn += 1 
                elif cpurand == 5:
                    pygame.Surface.blit(window, ximage, s6)
                    sd[5] = 1
                    turn += 1 
                elif cpurand == 6:
                    pygame.Surface.blit(window, ximage, s7)
                    sd[6] = 1
                    turn += 1 
                elif cpurand == 7:
                    pygame.Surface.blit(window, ximage, s8)
                    sd[7] = 1
                    turn += 1 
                elif cpurand == 8:
                    pygame.Surface.blit(window, ximage, s9)
                    sd[8] = 1
                    turn += 1 
        
                
        if turn%2 == 0:
            cpurand = random.randint(0,8)
            if sd[cpurand] == 0:
                if cpurand == 0 and sd[0]==0:
                    pygame.Surface.blit(window, oimage, s1)
                    sd[0] = 2
                    turn += 1 
                elif cpurand == 1 and sd[1]==0:
                    pygame.Surface.blit(window, oimage, s2)
                    sd[1] = 2
                    turn += 1 
                elif cpurand == 2 and sd[2]==0:
                    pygame.Surface.blit(window, oimage, s3)
                    sd[2] = 2
                    turn += 1 
                elif cpurand == 3 and sd[3]==0:
                    pygame.Surface.blit(window, oimage, s4)
                    sd[3] = 2
                    turn += 1 
                elif cpurand == 4 and sd[4]==0:
                    pygame.Surface.blit(window, oimage, s5)
                    sd[4] = 2
                    turn += 1 
                elif cpurand == 5 and sd[5]==0:
                    pygame.Surface.blit(window, oimage, s6)
                    sd[5] = 2
                    turn += 1 
                elif cpurand == 6 and sd[6]==0:
                    pygame.Surface.blit(window, oimage, s7)
                    sd[6] = 2
                    turn += 1 
                elif cpurand == 7 and sd[7]==0:
                    pygame.Surface.blit(window, oimage, s8)
                    sd[7] = 2
                    turn += 1 
                elif cpurand == 8 and sd[8]==0:
                    pygame.Surface.blit(window, oimage, s9)
                    sd[8] = 2
                    turn += 1 
            
        
# =============================================================================
#                 else:
#                     cpurand = random.randint(0,8)
# =============================================================================
                

        if sd[0] == 1 and sd[1] == 1 and sd[2] == 1:
            xW = True
        if sd[0] == 2 and sd[1] == 2 and sd[2] == 2:
            oW = True
        if sd[3] == 1 and sd[4] == 1 and sd[5] == 1:
            xW = True
        if sd[3] == 2 and sd[4] == 2 and sd[5] == 2:
            oW = True
        if sd[6] == 1 and sd[7] == 1 and sd[8] == 1:
            xW = True
        if sd[6] == 2 and sd[7] == 2 and sd[8] == 2:
            oW = True
        if sd[0] == 1 and sd[3] == 1 and sd[6] == 1:
            xW = True
        if sd[0] == 2 and sd[2] == 2 and sd[6] == 2:
            oW = True
        if sd[1] == 1 and sd[4] == 1 and sd[7] == 1:
            xW = True
        if sd[1] == 2 and sd[4] == 2 and sd[7] == 2:
            oW = True
        if sd[2] == 1 and sd[6] == 1 and sd[8] == 1:
            xW = True
        if sd[2] == 2 and sd[6] == 2 and sd[8] == 2:
            oW = True
        if sd[0] == 1 and sd[4] == 1 and sd[8] == 1:
            xW = True
        if sd[0] == 2 and sd[4] == 2 and sd[8] == 2:
            oW = True
        if sd[6] == 1 and sd[4] == 1 and sd[2] == 1:
            xW = True
        if sd[6] == 2 and sd[4] == 2 and sd[2] == 2:
            oW = True   
        if all(sd) != 0 and oW == False and xW == False:
            draw = True
        
 

                    
    
        
    #print(turn)
        
            
        if xW == True:
            #xwin()
            print("AI wins.")
# =============================================================================
#             print("Rewarding sequence: " + str(moves))
#             turn1list.append(moves[0])
#             turn2list.append(moves[1])
#             turn3list.append(moves[2])
            winlist.append("win")
#             if len(moves) > 3:
#                 turn4list.append(moves[3])
#                     
#             with open('CSVs_For_TicTacToe\Turn1.csv', 'w') as f_object:
#                 writer_object = writer(f_object)
#                 writer_object.writerow(turn1list)
#                 f_object.close()
#             
#             with open('CSVs_For_TicTacToe\Turn2.csv', 'w') as f_object:
#                 writer_object = writer(f_object)
#                 writer_object.writerow(turn2list)
#                 f_object.close()
#                 
#             with open('CSVs_For_TicTacToe\Turn3.csv', 'w') as f_object:
#                 writer_object = writer(f_object)
#                 writer_object.writerow(turn3list)
#                 f_object.close()
#             
#             with open('CSVs_For_TicTacToe\Turn4.csv', 'w') as f_object:
#                 writer_object = writer(f_object)
#                 writer_object.writerow(turn4list)
#                 f_object.close()
# =============================================================================
            with open('CSVs_For_TicTacToe\Wins.csv', 'w') as f_object:
               writer_object = writer(f_object)
               writer_object.writerow(winlist)
               f_object.close()
            
            print(len(turn1list))
            print(len(turn2list))
            print(len(turn3list))
            print(len(turn4list))
                
            pygame.quit()
            

                    
                
            pygame.quit()
        if oW == True:
            #owin()
            print("AI loses.")
            print("Punishing sequence: " + str(moves))
            turn1list.remove(moves[0])
            turn2list.remove(moves[1])
            turn3list.remove(moves[2])
            winlist.append("loss")
            if len(moves) > 3:
                    turn4list.remove(moves[3])
                    
            with open('CSVs_For_TicTacToe\Turn1.csv', 'w') as f_object:
                writer_object = writer(f_object)
                writer_object.writerow(turn1list)
                f_object.close()
            
            with open('CSVs_For_TicTacToe\Turn2.csv', 'w') as f_object:
                writer_object = writer(f_object)
                writer_object.writerow(turn2list)
                f_object.close()
                
            with open('CSVs_For_TicTacToe\Turn3.csv', 'w') as f_object:
                writer_object = writer(f_object)
                writer_object.writerow(turn3list)
                f_object.close()
            
            with open('CSVs_For_TicTacToe\Turn4.csv', 'w') as f_object:
                writer_object = writer(f_object)
                writer_object.writerow(turn4list)
                f_object.close()
            
            with open('CSVs_For_TicTacToe\Wins.csv', 'w') as f_object:
               writer_object = writer(f_object)
               writer_object.writerow(winlist)
               f_object.close()
                
            print(len(turn1list))
            print(len(turn2list))
            print(len(turn3list))
            print(len(turn4list))
                
            pygame.quit()
            
            
            
            
        if draw == True:
            #drawmessage()
            print("Draw.")
            print("Drew with the following moves: " + str(moves))
            winlist.append("draw")
            with open('CSVs_For_TicTacToe\Wins.csv', 'w') as f_object:
               writer_object = writer(f_object)
               writer_object.writerow(winlist)
               f_object.close()
            print(len(turn1list))
            print(len(turn2list))
            print(len(turn3list))
            print(len(turn4list))
            pygame.quit()
        
    
    pygame.display.update()
    
    
